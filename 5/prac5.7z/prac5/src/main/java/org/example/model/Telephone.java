package org.example.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "telephones")
public class Telephone {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "producer")
    private String producer;
    @Column(name = "battery_capacity")
    private Short battery_capacity;
    @Column(name = "seller_num")
    private Short seller_num;
    @Column(name = "pr_type")
    private String pr_type;
    @Column(name = "price")
    private float price;
    @Column(name = "name")
    private String name;
}
