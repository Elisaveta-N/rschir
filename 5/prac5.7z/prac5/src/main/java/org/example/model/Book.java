package org.example.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "books")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "author")
    private String author;
    @Column(name = "seller_num")
    private Short seller_num;
    @Column(name = "pr_type")
    private String pr_type;
    @Column(name = "price")
    private float price;
    @Column(name = "name")
    private String name;

}